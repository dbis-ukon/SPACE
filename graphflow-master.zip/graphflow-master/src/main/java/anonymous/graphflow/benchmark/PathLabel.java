package anonymous.graphflow.benchmark;

import java.util.List;

public class PathLabel implements Comparable<Object> {
    long cost;
    List<String> variableSequence;
    List<String> queryVariableSequence;
    List<String> relationshipTypes;


    PathLabel(long cost, List<String> variableSequence, List<String> queryVariableSequence, List<String> relationshipTypes) {
        this.cost = cost;
        this.variableSequence = variableSequence;
        this.queryVariableSequence = queryVariableSequence;
        this.relationshipTypes = relationshipTypes;
    }

    @Override
    public int compareTo(Object o) {
        return Long.compare(this.cost, ((PathLabel)o).cost);
    }
}
