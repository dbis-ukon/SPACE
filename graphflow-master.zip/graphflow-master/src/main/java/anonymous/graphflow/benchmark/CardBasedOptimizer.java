package anonymous.graphflow.benchmark;

import ca.waterloo.dsg.graphflow.query.structuredquery.QueryGraph;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import ca.waterloo.dsg.graphflow.graph.Graph;
import ca.waterloo.dsg.graphflow.query.structuredquery.QueryRelation;

public class CardBasedOptimizer {

    private HashMap<String,Long> cardninalitiesMap = new HashMap<>();


    public CardBasedOptimizer(Graph g, String baseCardinalitiesFile) {
        try {
            File myObj = new File(baseCardinalitiesFile);
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String line = myReader.nextLine();
                String[] splitted = line.split(":");
                String pattern = splitted[0];
                String cardVector = splitted[1];

                String[] cardSplitted = cardVector.split(" ");
                long cardinality = (long) Double.parseDouble(cardSplitted[cardSplitted.length - 1]);
                pattern = pattern.replaceAll("\\s+", "");
                //System.out.println(pattern + " ### "+cardinality);
                this.cardninalitiesMap.put(pattern, cardinality);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        //System.out.println(this.cardninalitiesMap.size());
    }

    public List<String> determine_sequence(QueryGraph queryGraph) {
        //System.out.println("determine_sequence_from_base_cardinalities");
        //System.out.println();
        PriorityQueue<PathLabel> queue = new PriorityQueue<>();
        for(String src : queryGraph.getAllVariableNames()) {
            for(String trg : queryGraph.getAllNeighborVariables(src)) {
                for(QueryRelation qr : queryGraph.getAdjacentRelations(src,trg)) {
                    if(qr.getFromQueryVariable().getVariableName().equals(src)) {
                        List<String> labelsAndTypes = new ArrayList<>();
                        labelsAndTypes.add(qr.getFromQueryVariable().getVariableType());
                        labelsAndTypes.add(qr.getRelationType());
                        labelsAndTypes.add(qr.getToQueryVariable().getVariableType());
                        List<String> varSeq = new ArrayList<>();
                        varSeq.add(src);
                        varSeq.add(trg);
                        List<String> querySeq = new ArrayList<>(varSeq);
                        queue.add(new PathLabel(this.evaluateRelationTypesSequence(labelsAndTypes), varSeq, querySeq, labelsAndTypes));
                        //System.out.println(src + " " + trg + " " + qr.getFromQueryVariable().getVariableType()+ " " + qr.getRelationType()+ " " + qr.getToQueryVariable().getVariableType()+" "+this.evaluateRelationTypesSequence(labelsAndTypes));
                        //System.out.println(varSeq+" "+labelsAndTypes+" "+);
                    }
                }
            }

            //queue.add(new PathLabel(0, varSeq, labelsAndTypes));
        }

        while(!queue.isEmpty()) {
            PathLabel currentLabel = queue.poll();
            //System.out.println("***** "+currentLabel.cost+" "+currentLabel.queryVariableSequence);
            if(currentLabel.variableSequence.size() == queryGraph.getAllVariableNames().size()) {
                return currentLabel.queryVariableSequence;
            }

            // Expand search forward
            Set<String> neighbors = queryGraph.getAllNeighborVariables(currentLabel.variableSequence.get(currentLabel.variableSequence.size()-1));
            for(String n : neighbors) {
                if(currentLabel.variableSequence.contains(n))
                    continue;
                List<String> neighborRelationTypesSequence = new ArrayList<>(currentLabel.relationshipTypes);
                neighborRelationTypesSequence.add(queryGraph.getAdjacentRelations(currentLabel.variableSequence.get(currentLabel.variableSequence.size()-1), n).get(0).getRelationType());
                neighborRelationTypesSequence.add(queryGraph.getAdjacentRelations(currentLabel.variableSequence.get(currentLabel.variableSequence.size()-1), n).get(0).getToQueryVariable().getVariableType());
                long neighborCost = currentLabel.cost + this.evaluateRelationTypesSequence(neighborRelationTypesSequence); // Evaluate the cost of relationTypesSequence
                List<String> neighborVariableSequence = new ArrayList<>(currentLabel.variableSequence);
                neighborVariableSequence.add(n);
                List<String> neighborQueryVariableSequence = new ArrayList<>(currentLabel.queryVariableSequence);
                neighborQueryVariableSequence.add(n);
                queue.add(new PathLabel(neighborCost, neighborVariableSequence, neighborQueryVariableSequence, neighborRelationTypesSequence));
                //System.out.println(currentLabel.variableSequence+" "+currentLabel.queryVariableSequence+" "+neighborVariableSequence+" "+neighborQueryVariableSequence+" "+neighborRelationTypesSequence+" "+neighborCost);
            }

            // Expand search backward
            neighbors = queryGraph.getAllNeighborVariables(currentLabel.variableSequence.get(0));
            for(String n : neighbors) {
                if(currentLabel.variableSequence.contains(n))
                    continue;
                List<String> neighborRelationTypesSequence = new ArrayList<>();
                neighborRelationTypesSequence.add(queryGraph.getAdjacentRelations(currentLabel.variableSequence.get(0), n).get(0).getFromQueryVariable().getVariableType());
                neighborRelationTypesSequence.add(queryGraph.getAdjacentRelations(currentLabel.variableSequence.get(0), n).get(0).getRelationType());
                neighborRelationTypesSequence.addAll(currentLabel.relationshipTypes);
                long neighborCost = currentLabel.cost + this.evaluateRelationTypesSequence(neighborRelationTypesSequence);; // Evaluate the cost of relationTypesSequence
                List<String> neighborVariableSequence = new ArrayList<>();
                neighborVariableSequence.add(n);
                neighborVariableSequence.addAll(currentLabel.variableSequence);
                List<String> neighborQueryVariableSequence = new ArrayList<>();
                neighborQueryVariableSequence.addAll(currentLabel.queryVariableSequence);
                neighborQueryVariableSequence.add(n);
                queue.add(new PathLabel(neighborCost, neighborVariableSequence, neighborQueryVariableSequence, neighborRelationTypesSequence));
                //System.out.println(currentLabel.variableSequence+" "+currentLabel.queryVariableSequence+" "+neighborVariableSequence+" "+neighborQueryVariableSequence+" "+neighborRelationTypesSequence+" "+neighborCost);
            }
        }
        return null;
    }

    /*
TODO return cardinality
 */
    private long evaluateRelationTypesSequence(List<String> neighborRelationTypesSequence) {
        String queryPattern = "";
        for(String s:neighborRelationTypesSequence)
            queryPattern += s;
        //System.out.println("--- Evaluating "+queryPattern);
        Long card = this.cardninalitiesMap.get(queryPattern);
        if(card == null)
            return 1;
        return card.longValue();
    }

}
