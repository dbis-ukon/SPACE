package anonymous.graphflow.benchmark;

import ca.waterloo.dsg.graphflow.graph.Graph;
import ca.waterloo.dsg.graphflow.graph.GraphDBState;
import ca.waterloo.dsg.graphflow.graph.TypeAndPropertyKeyStore;
import ca.waterloo.dsg.graphflow.query.operator.InMemoryOutputSink;
import ca.waterloo.dsg.graphflow.query.parser.StructuredQueryParser;
import ca.waterloo.dsg.graphflow.query.planner.OneTimeMatchQueryPlanner;
import ca.waterloo.dsg.graphflow.query.plans.OneTimeMatchQueryPlan;
import ca.waterloo.dsg.graphflow.query.structuredquery.QueryGraph;

import java.io.*;
import java.util.*;

public class Benchmark {
    public static void main(String[] args) {

        String edges_file;
        String nodes_file;
        String directory;
        String queries_file;
        String card_file;

        GraphDBState.reset();

        if(args[0].equals("create")) {
            System.out.println("Creating new graph store in "+args[3]+".");
            edges_file = args[1];
            nodes_file = args[2];
            directory = args[3];
            getGraph(edges_file, nodes_file);
            try {
                Graph.getInstance().serializeAll(directory);
                TypeAndPropertyKeyStore.getInstance().serializeAll(directory);
            }
            catch (IOException|InterruptedException e) {
                System.err.println(e.getMessage());
            }
            System.out.println("Graph store created");
        }
        else if (args[0].equals("graphflow")) {
            directory = args[1];
            System.out.println("Loading graph from "+directory+".");
            queries_file = args[2];

            try {
                Graph.getInstance().deserializeAll(directory);
                TypeAndPropertyKeyStore.getInstance().deserializeAll(directory);
            }
            catch (IOException | ClassNotFoundException | InterruptedException e) {
                System.err.println(e.getMessage());
            }

            System.out.println("Loading queries from "+queries_file+".");
            List<String> testQueries = loadCypherTestQueries(queries_file);

            System.out.println("Starting benchmark.");
            for(String query : testQueries) {
                System.out.print(query+"\t");
                List<String> queryResults = run_query(query);
                System.out.println("\t"+queryResults.size());
            }
            System.out.println("Benchmark completed.");
        }
        else if (args[0].equals("card")) {
            directory = args[1];
            queries_file = args[2];
            card_file = args[3];

            try {
                Graph.getInstance().deserializeAll(directory);
                TypeAndPropertyKeyStore.getInstance().deserializeAll(directory);
            }
            catch (IOException | ClassNotFoundException | InterruptedException e) {
                System.err.println(e.getMessage());
            }

            System.out.println("Loading queries from "+queries_file+".");
            List<String> testQueries = loadCypherTestQueries(queries_file);

            System.out.println("Loading cardinalities from "+card_file+".");
            CardBasedOptimizer optimizer = new CardBasedOptimizer(Graph.getInstance(), card_file);

            System.out.println("Starting benchmark.");
            for(String query : testQueries) {
                System.out.print(query+"\t");
                List<String> queryResults = run_query_single_ordering(query,optimizer);
                System.out.println("\t"+queryResults.size());
            }
            System.out.println("Benchmark completed.");
        }
        else {
            System.err.println("Invalid input");
            System.exit(1);
        }
    }

    private static List<String> loadCypherTestQueries(String cypherQueriesFilePath) {
        List<String> queries = new ArrayList<>();
        boolean flag = true;
        try {
            File myObj = new File(cypherQueriesFilePath);
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String query = myReader.nextLine();
                queries.add(query);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        return queries;
    }

    private static void getGraph(String relationshipsAndTypesFilePath, String nodesAndLabelsFilePath) {

        GraphDBState.reset();
        Graph graph = Graph.getInstance();
        /*
        READING VERTEX LABELS
         */
        HashMap<Integer, Short> vertex_label_map = new HashMap<>();
        try {
            File myObj = new File(nodesAndLabelsFilePath);
            Scanner myReader = new Scanner(myObj);
            myReader.nextLine(); // Skipping header
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                String[] info = data.split(",");
                String labels_list = info[1].replace("\"", "").replace("[", "").replace("]", "");
                String[] labels = labels_list.split(",");
                vertex_label_map.put(Integer.parseInt(info[0]), TypeAndPropertyKeyStore.getInstance().mapStringTypeToShortOrInsert(labels[0]));
                Graph.getInstance().addVertex(Integer.parseInt(info[0]), TypeAndPropertyKeyStore.getInstance().mapStringTypeToShortOrInsert(labels[0]), null);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        /*
        READING EDGES
         */

        ArrayList<int[]> edge_list = new ArrayList<>();
        ArrayList<Short> edge_types_list = new ArrayList<>();
        try {
            File myObj = new File(relationshipsAndTypesFilePath);
            Scanner myReader = new Scanner(myObj);
            myReader.nextLine(); // Skipping header
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                String[] info = data.split(",");
                String et = info[2].replace("\"", "");

                int[] e = new int[2];
                e[0] = Integer.parseInt(info[0]);
                e[1] = Integer.parseInt(info[1]);
                edge_list.add(e);
                edge_types_list.add(TypeAndPropertyKeyStore.getInstance().mapStringTypeToShortOrInsert(et));
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        /*
        Populating arrays
         */

        int[][] edges = new int[edge_list.size()][];
        for (int i = 0; i < edge_list.size(); i++) {
            edges[i] = edge_list.get(i);
        }
        edge_list.clear();
        short[] edgeTypes = new short[edges.length];
        for (int i = 0; i < edge_types_list.size(); i++) {
            edgeTypes[i] = edge_types_list.get(i);
        }
        edge_types_list.clear();

        short[][] vertexTypes = new short[edges.length][];
        for (int i = 0; i < vertexTypes.length; i++) {
            vertexTypes[i] = new short[2];
            vertexTypes[i][0] = vertex_label_map.get(edges[i][0]);
            vertexTypes[i][1] = vertex_label_map.get(edges[i][1]);
        }

        for (int i = 0; i < edges.length; i++)
            graph.addEdgeTemporarily(edges[i][0], edges[i][1], vertex_label_map.get(edges[i][0]), vertex_label_map.get(edges[i][1]), null, null, edgeTypes[i], null);

        graph.finalizeChanges();
    }

    private static List<String> run_query(String query) {
        List<String> orig_results = null;

        long endTime = 0;

        InMemoryOutputSink inMemoryOutputSink = new InMemoryOutputSink();
        OneTimeMatchQueryPlanner planner = new OneTimeMatchQueryPlanner(new StructuredQueryParser().parse(query), inMemoryOutputSink);

        OneTimeMatchQueryPlan plan = (OneTimeMatchQueryPlan) planner.plan();

        long startTime = System.nanoTime();
        plan.execute();
        orig_results = inMemoryOutputSink.getResults();
        endTime = System.nanoTime() - startTime;
        System.out.print("\t" + (endTime / 1000000.0));

        return orig_results;
    }

    private static List<String> run_query_single_ordering(String query, CardBasedOptimizer optimizer) {
        InMemoryOutputSink inMemoryOutputSink = new InMemoryOutputSink();

        long endTime = 0;
        OneTimeMatchQueryPlanner planner = new OneTimeMatchQueryPlanner(new StructuredQueryParser().parse(query), inMemoryOutputSink);
        QueryGraph queryGraph = planner.getQueryGraph();

        List<String> variableSequence = optimizer.determine_sequence(queryGraph);

        long startTime = System.nanoTime();
        OneTimeMatchQueryPlan plan = (OneTimeMatchQueryPlan) planner.plan(variableSequence);
        plan.execute();
        List<String> orig_results = inMemoryOutputSink.getResults();
        endTime = System.nanoTime() - startTime;
        System.out.print("\t" + (endTime / 1000000.0));
        return orig_results;
    }
}
