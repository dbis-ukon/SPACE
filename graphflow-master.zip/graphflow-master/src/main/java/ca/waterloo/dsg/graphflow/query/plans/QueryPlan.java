package ca.waterloo.dsg.graphflow.query.plans;

/**
 * Interface for creating query plans.
 */
public interface QueryPlan {
}
