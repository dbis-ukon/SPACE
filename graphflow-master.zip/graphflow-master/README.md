Graphflow
=========

NOTICE: We have extended graph flow with classes in anonymous.graphflow.benchmark
and we have fixed a bug in the code of the system. Parts of this readme come from the original authors.
We mark which parts are our own.

Graphflow is an in-memory graph database that supports continuous queries.
Graphflow's query language is based on [openCypher](http://opencypher.org).
Currently Graphflow supports a subset of queries expressible in openCypher.
In addition it supports several extensions to openCypher for expressing 
continuous queries. Throughout the code base and documentation, we refer to 
this extended version of openCypher as openCypher++.

## Build steps

Graphflow requires Java 8, and uses Gradle as its build tool.

* Do a full clean build: `./gradlew clean build installDist`
* Subsequent builds: `./gradlew build installDist`
* Build without tests: `./gradlew build installDist -x test`

## Running the Benchmark

The main function for out benchmark is in the Benchmark.java. Use the following options to reproduce our experiments.

* Create a new graph storage (serialize the input graph; saves loading time):  
  `[EXECUTABLE] create [EDGES_FILE] [NODES_FILE] [DB_DIRECTORY]`
  
  For example:
  `[EXECUTABLE] create snb-edges.csv snb-nodes.csv dir/snb`
  
* Run Benchmark using the method of Graphflow to determine the node variable sequence:  
  `[EXECUTABLE] graphflow [DB_DIRECTORY] [QUERIES_FILE]`
  
  For example:
  `[EXECUTABLE] graphflow dir/snb graphflow-test-cypher.csv`
  
* * Run Benchmark using our extension that considers precomputed cardinalities:  
  `[EXECUTABLE] card [DB_DIRECTORY] [QUERIES_FILE] [CARDINALITIES FILE]`
  
  For example:
  `[EXECUTABLE] card dir/snb graphflow-test-cypher.csv graphflow-test-subpattern-card-space.csv`

## Licensing

Graphflow is an open source software under the Apache 2.0 license.
